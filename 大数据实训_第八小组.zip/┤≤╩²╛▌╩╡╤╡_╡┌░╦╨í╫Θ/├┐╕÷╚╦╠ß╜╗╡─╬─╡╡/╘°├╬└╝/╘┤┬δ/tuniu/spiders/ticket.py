# -*- coding: utf-8 -*-
import codecs
import csv
import os

import time
from lxml import etree

import scrapy
import sys

from pip._vendor import requests

reload(sys)
sys.setdefaultencoding('utf-8')

class TicketSpider(scrapy.Spider):
	name = "ticket"#爬虫的名字
	start_urls = ["http://menpiao.tuniu.com/cat_0_0_0_0_0_0_1_1_1.html", ]  #初始链接
	for i in range(2,335):
		url = 'http://menpiao.tuniu.com/cat_0_0_0_0_0_0_1_1_' + str(i) + '.html'
		start_urls.append(url)



	def parse(self, response):#解析函数，response网页请求响应

		html_content = response.body
		selector = etree.HTML(html_content)
		attractions = selector.xpath('//*[@id="niuren_list"]/div[3]/div/ul/li')
		print '_________________________________________________'

		count = len(attractions)
		for i in range(1,count+1):
			#景点列表xpath并解析
			xpath_str = '//*[@id="niuren_list"]/div[3]/div/ul/li[' + str(i) +']'

			#拼接景点图片xpath,并解析
			attractions_pic = selector.xpath(xpath_str + '/div[@class="photo"]/a/img/@src')[0]
			if attractions_pic == 'http://img.tuniucdn.com/site/images/common/white.gif':
				attractions_pic = selector.xpath(xpath_str + '/div[@class="photo"]/a/img/@data-src')[0]
			print attractions_pic

			#拼接景点名称xpath并解析
			attractions_name = selector.xpath(xpath_str + '/h3/a/text()')[0]

			#拼接景点地址
			attractions_place_1 = selector.xpath(xpath_str + '/h3/span[1]/a[1]/text()')[0]
			try:
				attractions_place_2 = selector.xpath(xpath_str + '/h3/span[1]/a[2]/text()')[0]
			except:
				attractions_place_2 = ''
			#拼接地址
			attractions_place = attractions_place_1 + attractions_place_2


			# 拼接景点票价xpath并解析
			attractions_price = selector.xpath(xpath_str + '/div[2]/span/em/text()')[0]
			print attractions_name
			print attractions_place
			print attractions_price


			############写文件#############
			path = r"d:/tuniu_spider/"
			# 判断文件夹是否存在
			isExists = os.path.exists(path)
			if not isExists:
				# 不存在就新建
				os.makedirs(path)
			# 切换工作目录
			os.chdir(path)
			# 下载图片
			img = requests.get(attractions_pic)
			fo = open(attractions_name + '.jpg', 'ab')
			fo.write(img.content)

			f = file('test.csv', 'ab')
			f.write(codecs.BOM_UTF8)
			writer = csv.writer(f)
			writer.writerow([attractions_name, attractions_place, attractions_price])

			#延时处理，防止被封
			time.sleep(2)


