# Scrapy_start
start to use scrapy , there are mang things that can be better , I'll redo it in some time
