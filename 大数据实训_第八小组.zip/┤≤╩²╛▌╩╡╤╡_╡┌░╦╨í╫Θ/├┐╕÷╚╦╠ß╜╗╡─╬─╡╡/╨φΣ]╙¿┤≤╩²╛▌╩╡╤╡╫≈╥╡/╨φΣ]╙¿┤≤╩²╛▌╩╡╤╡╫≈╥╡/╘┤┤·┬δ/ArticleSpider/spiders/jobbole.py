# -*- coding: utf-8 -*-
import scrapy
import re
import  array
from ArticleSpider.items import ArticlespiderItem

from scrapy.http import Request
from urllib import parse

class JobboleSpider(scrapy.Spider):
    name = 'jobbole'
    allowed_domains = ['piao.ctrip.com']
    start_urls = ['http://piao.ctrip.com/dest/u-_d6_d0_b9_fa/s-tickets/P1/']

    def parse(self, response):
       item = ArticlespiderItem()
       items = response.css(".searchresult_product04")
       for x in items:
            item["name"] = x.css(".search_ticket_title a::text")[0].extract().strip()
            item["pos"] = "".join(x.css('.adress_name a::text').extract())
            item["price"] = x.css('.search_ticket_table tr .base_price::text')[1].extract().strip()
            item["img"] = x.css('.search_ticket_caption.basefix a img ::attr(src)')[0].extract()
            yield item

       next_url = response.css(".pkg_page.basefix .down ::attr(href)").extract_first("")
       if next_url:
         print(parse.urljoin(response.url, next_url))
         yield Request(url=parse.urljoin(response.url, next_url), callback=self.parse)
    pass
