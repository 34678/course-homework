# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.conf import settings
import pymongo
class ArticlespiderPipeline(object):
    #将数据存到mongodb里。
    def __init__(self):
        self.server = settings['MONGO_SERVER']
        self.port = settings['MONGO_PORT']
        # 数据库登录需要帐号密码的话
        # self.client.admin.authenticate(settings['MINGO_USER'], settings['MONGO_PSW'])
        self.db = settings["MONGO_DB"]
        self.coll = settings["MONGO_COLL"]
        connection = pymongo.MongoClient(self.server, self.port)
        db = connection[self.db]
        self.collection = db[self.coll]

    def process_item(self, item, spider):
        postItem = dict(item)
        self.collection.insert(postItem)
        return item

